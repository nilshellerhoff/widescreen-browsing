# widescreen-browsing
Chrome and Firefox extension, which reduces the width of webpages on widescreen monitors
